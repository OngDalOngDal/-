package com.disaster.service;

import com.disaster.domain.WriteDTO;
import com.disaster.mapper.PostReportMapper;
import com.disaster.mapper.WriteMapper;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Service
public class WriteService {

    private final WriteMapper writeMapper;
    private final PostReportMapper postReportMapper; 

    public WriteService(WriteMapper writeMapper, PostReportMapper postReportMapper) {
        this.writeMapper = writeMapper;
        this.postReportMapper = postReportMapper;
    }

    public void createPost(WriteDTO dto) {
        writeMapper.insert(dto);
    }

    public List<WriteDTO> getAllPosts() {
        return writeMapper.findAllPosts();
    }

    public List<WriteDTO> getLatestPosts() {
        return writeMapper.selectLatestPost();
    }
    // post_id로 게시글 조회
    @Transactional
    public WriteDTO getPostById(Long postId) {
        // 1. 조회수를 1 증가시키는 UPDATE 쿼리를 먼저 실행
        writeMapper.incrementViewCount(postId);
        // 2. 그 다음, 증가된 정보가 포함된 게시글을 SELECT
        return writeMapper.findById(postId);
    }
    // 글 삭제 관련
 // ✅ 4. @Transactional 추가 및 로직 수정
    @Transactional
    public void deletePost(Long postId) {
        // 1. 자식 테이블(신고 내역)의 데이터를 먼저 삭제
        postReportMapper.deleteReportsByPostId(postId);

        // 2. 부모 테이블(게시글)의 데이터를 삭제
        writeMapper.deletePost(postId);
    }
    // 글 수정 관련
    public void updatePost(WriteDTO dto) {
        writeMapper.updatePost(dto);
    }
    // 기존 getAllPosts는 이제 사용하지 않거나 페이징용으로 수정합
    public List<WriteDTO> getAllPosts(int page, int pageSize) {
    	int offset = (page - 1) * pageSize;
    	return writeMapper.findPostsPaginated(offset, pageSize);
    }
    // 전체 게시글 수를 가져오는 메소드 추가
    public int getPostCount() {
    	return writeMapper.countAllPosts();
    }
    /** ✅ 검색된 게시글 목록 조회 (페이징) */
    public List<WriteDTO> searchPosts(String keyword, int page, int pageSize) {
        int offset = (page - 1) * pageSize;
        return writeMapper.findSearchedPostsPaginated(keyword, offset, pageSize);
    }
    /** ✅ 검색된 게시글 수 조회 */
    public int getSearchPostCount(String keyword) {
        return writeMapper.countSearchedPosts(keyword);
    }
    
    
}
