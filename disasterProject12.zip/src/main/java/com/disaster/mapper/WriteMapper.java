package com.disaster.mapper;

import com.disaster.domain.WriteDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface WriteMapper {

    List<WriteDTO> selectAll();
    
    List<WriteDTO> findAllPosts(); 

    void insert(WriteDTO dto);
    WriteDTO findById(Long id);
    void update(WriteDTO dto);

    void delete(Long id);

    List<WriteDTO> selectLatestPost();
    
    // 게시글 삭제
    void deletePost(@Param("postId") Long postId);
    // 게시글 수정
    void updatePost(WriteDTO dto);
    
    // 목록 페이지 버튼
    List<WriteDTO> findAllPostsWithLimit(@Param("offset") int offset, 
            @Param("limit") int limit);
    
    // 전체 게시글 수 조회
    int countAllPosts();

    // 페이징 처리된 게시글 목록 조회
    List<WriteDTO> findPostsPaginated(@Param("offset") int offset, @Param("limit") int limit); 
    
    // 검색된 게시글 수 조회
    int countSearchedPosts(@Param("keyword") String keyword);

	// 페이징 처리된 검색 게시글 목록 조회
    List<WriteDTO> findSearchedPostsPaginated(@Param("keyword") String keyword, @Param("offset") int offset, @Param("limit") int limit);
    
    // 조회수 증가를 위한 메소드 선언 추가
    void incrementViewCount(@Param("postId") Long postId);
}
