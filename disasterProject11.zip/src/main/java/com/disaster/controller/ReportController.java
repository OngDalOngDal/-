package com.disaster.controller;

import com.disaster.domain.CommentDTO;
import com.disaster.domain.CommentReportDTO;
import com.disaster.domain.CustomUserDetails;
import com.disaster.domain.PostReportDTO;
import com.disaster.domain.WriteDTO;
import com.disaster.service.PostReportService;
import com.disaster.service.WriteService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;

@Controller
@RequiredArgsConstructor
@RequestMapping("/report")
public class ReportController {

    private final PostReportService postreportService; // ✅ PostReportService -> ReportService
    private final WriteService writeService;

    // 신고 폼 열기
    @GetMapping("/post/{postId}")
    public String showReportForm(@PathVariable("postId") Long postId,
                                 Model model,
                                 HttpServletRequest request) {

        model.addAttribute("postReportDTO", new PostReportDTO());
        model.addAttribute("postId", postId);

        WriteDTO post = writeService.getPostById(postId);
        model.addAttribute("post", post);

        // '취소' 버튼을 위한 이전 페이지 URL 전달
        String referer = request.getHeader("referer");
        model.addAttribute("previousPage", referer != null ? referer : "/community/main");

        return "report/reportForm"; // ✅ 템플릿 경로 확인
    }

    // 신고 제출
    @PostMapping("/post/{postId}")
    public String reportPost(@PathVariable("postId") Long postId,
                             @ModelAttribute PostReportDTO postReportDTO) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        // ✅✅✅ 핵심 수정 부분: CustomUserDetails로 현재 로그인 사용자 정보를 가져옵니다.
        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
            CustomUserDetails reporter = (CustomUserDetails) auth.getPrincipal();
            postReportDTO.setPostId(postId);
            postReportDTO.setReporterMemberId(reporter.getMemberId()); // DTO 필드에 맞게 설정

            // ✅ 서비스 메소드 이름 일관성 유지
            postreportService.createPostReport(postReportDTO); 
        }

        // 신고 완료 후 알림을 위한 파라미터 추가
        return "redirect:/community/communityDetail/" + postId + "?reported=true";
    }
    
    // 댓글신고 폼 열기
 // ✅ 1. 댓글 신고 폼을 보여주는 메소드
    @GetMapping("/comment/{commentId}")
    public String reportCommentForm(@PathVariable("commentId") Long commentId,
                                    @RequestParam("postId") Long postId, // 리다이렉트를 위해 postId도 받음
                                    Model model) {
        
        CommentDTO comment = commentService.getCommentById(commentId);
        
        CommentReportDTO reportDto = new CommentReportDTO();
        reportDto.setCommentId(commentId); // DTO에 commentId 설정

        model.addAttribute("reportTarget", "댓글");
        model.addAttribute("targetContent", comment.getBody());
        model.addAttribute("commentReportDto", reportDto); // DTO 이름을 명확하게 전달
        model.addAttribute("postId", postId); // 리다이렉트를 위해 postId 전달
        model.addAttribute("formAction", "/report/comment");

        return "report/reportForm";
    }

    // ✅ 2. 댓글 신고를 처리하는 메소드
    @PostMapping("/comment")
    public String submitCommentReport(@ModelAttribute("commentReportDto") CommentReportDTO reportDto,
                                      @RequestParam("postId") Long postId, // 리다이렉트를 위해 postId 받음
                                      Authentication authentication,
                                      RedirectAttributes redirectAttributes) {
                                      
        CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
        reportDto.setReporterMemberId(userDetails.getMemberId());
        
        reportService.createCommentReport(reportDto);
        
        redirectAttributes.addFlashAttribute("message", "댓글이 정상적으로 신고되었습니다.");
        
        // 신고 후 원래 게시글 상세 페이지로 돌아감
        return "redirect:/community/communityDetail/" + postId; 
    }
}